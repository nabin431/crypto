# Crypto Pro Website (Complete)

## 📁 Structure
- /client — Frontend (HTML/CSS/JavaScript)
- /server — Backend (Node.js + MongoDB + JWT Auth)

## 🚀 How to Run

### Frontend
Open `client/index.html` in your browser or deploy to Netlify.

### Backend
1. Go to `server` folder
2. Run `npm install`
3. Create a `.env` file using `.env.example`
4. Run server using `node server.js`

### Features
- Live crypto prices (CoinGecko)
- Register/Login system (MongoDB + JWT)
